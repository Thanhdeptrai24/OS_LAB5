#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t sem_v, sem_e, sem_g;

int x1 = 2, x2 = 3, x3 = 4, x4 = 5, x5 = 6, x6 = 7;
int w, v, y, z, ans;

void* thread_a(void* arg) {
    w = x1 * x2;
    printf("w = %d\n", w);
    sem_post(&sem_v);
    return NULL;
}

void* thread_b(void* arg) {
    sem_wait(&sem_v);
    v = x3 * x4;
    printf("v = %d\n", v);
    sem_post(&sem_e);
    return NULL;
}

void* thread_c(void* arg) {
    sem_wait(&sem_e);
    y = v * x5;
    printf("y = %d\n", y);
    sem_post(&sem_g);
    return NULL;
}

void* thread_d(void* arg) {
    sem_wait(&sem_e);
    z = v * x6;
    printf("z = %d\n", z);
    sem_post(&sem_g);
    return NULL;
}

void* thread_e(void* arg) {
    sem_wait(&sem_g);
    y = w * y;
    printf("e: y = %d\n", y);
    sem_post(&sem_g);
    return NULL;
}

void* thread_f(void* arg) {
    sem_wait(&sem_g);
    z = w * z;
    printf("f: z = %d\n", z);
    sem_post(&sem_g);
    return NULL;
}

void* thread_g(void* arg) {
    sem_wait(&sem_g);
    ans = y + z;
    printf("Answer: %d\n", ans);
    return NULL;
}

int main() {
    pthread_t t_a, t_b, t_c, t_d, t_e, t_f, t_g;

    sem_init(&sem_v, 0, 0);
    sem_init(&sem_e, 0, 0);
    sem_init(&sem_g, 0, 0);

    pthread_create(&t_a, NULL, thread_a, NULL);
    pthread_create(&t_b, NULL, thread_b, NULL);
    pthread_create(&t_c, NULL, thread_c, NULL);
    pthread_create(&t_d, NULL, thread_d, NULL);
    pthread_create(&t_e, NULL, thread_e, NULL);
    pthread_create(&t_f, NULL, thread_f, NULL);
    pthread_create(&t_g, NULL, thread_g, NULL);

    pthread_join(t_a, NULL);
    pthread_join(t_b, NULL);
    pthread_join(t_c, NULL);
    pthread_join(t_d, NULL);
    pthread_join(t_e, NULL);
    pthread_join(t_f, NULL);
    pthread_join(t_g, NULL);

    sem_destroy(&sem_v);
    sem_destroy(&sem_e);
    sem_destroy(&sem_g);

    return 0;
}
