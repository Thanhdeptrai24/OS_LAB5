#include <stdio.h>
#include<semaphore.h>
#include <pthread.h>

#include<stdbool.h>
#include <unistd.h>
sem_t sem;
sem_t sem1;
int MSSV=1437;
int sells=0;
void* processA(){
	while(true){
		sem_wait(&sem);
		sells++;
		sem_post(&sem1);
		printf("Sell: %d\n\n",sells);
		sleep(0.2);
		
	}
}
int products=0;
void* processB(){
	while (true){
		sem_wait(&sem1);
		products++;

		printf("product: %d\n",products);
		sem_post(&sem);
		sleep(0.2);

	}
}
int main(){
	sem_init(&sem,0,0);
	sem_init(&sem1,0,MSSV);
	pthread_t threadA,threadB;
	pthread_create(&threadA,NULL,processA,NULL);
	pthread_create(&threadB,NULL,processB,NULL);
	pthread_join(threadA,NULL);
	pthread_join(threadB,NULL);
	return 0;
}
