#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define MAX_SIZE 100

int a[MAX_SIZE];
int size = 0;
sem_t semaphore;
void* producer(void* arg) {
    while (1) {
        sem_wait(&semaphore);
        if (size < MAX_SIZE) {
            int value = rand() % 100;
            a[size++] = value;
            printf("Producer: Size of array: %d\n", size);
        } else {
            printf("Producer: Array is full, cannot add more elements.\n");
        }
        sem_post(&semaphore);
        sleep(1);
    }
    return NULL;
}
void* consumer(void* arg) {
    while (1) {
        sem_wait(&semaphore);
        if (size > 0) {
            int removed = a[--size];
            printf("Consumer: Size of array: %d\n",  size);
        } else {
            printf("Consumer: Nothing in array a\n");
        }
        sem_post(&semaphore);
        sleep(2);
    }
    return NULL;
}
int main() {
    pthread_t producer_thread, consumer_thread;
    sem_init(&semaphore, 0, 1);
    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_create(&consumer_thread, NULL, consumer, NULL);
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);
    sem_destroy(&semaphore);
    return 0;
}
